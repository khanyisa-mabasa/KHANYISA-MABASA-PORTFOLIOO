# Predicting House Prices — Machine Learning Project

**Goal:** Build and evaluate regression models to predict house prices from property features.

## Contents
- `data/house_prices.csv` — synthetic sample dataset (1200 rows)
- `notebooks/house_price_prediction.ipynb` — Jupyter Notebook with full ML workflow
- `models/` — trained model saved (if created during generation)
- `images/feature_importance.png` — feature importance plot (if available)
- `requirements.txt` — dependencies
- `.gitignore`

## How to run
1. Create a virtual environment and activate it:

   ```bash
   python -m venv venv
   source venv/bin/activate  # or venv\\Scripts\\activate on Windows
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Jupyter and open the notebook:
   ```bash
   jupyter notebook notebooks/house_price_prediction.ipynb
   ```

## Models trained (in notebook)
- Linear Regression
- Random Forest Regressor
- XGBoost Regressor (optional, requires xgboost)

## Notes
- The dataset is synthetic but realistic; replace with a real Kaggle dataset for production.
- The notebook saves the Random Forest model to `models/rf_house_price_model.pkl`.
