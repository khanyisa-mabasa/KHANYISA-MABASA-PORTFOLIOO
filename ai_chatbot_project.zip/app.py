from flask import Flask, request, jsonify, render_template
import json

app = Flask(__name__, template_folder='frontend')

# Load FAQ
with open('data/faq.json') as f:
    faq_data = json.load(f)

def get_answer(user_question):
    user_question = user_question.lower()
    for item in faq_data:
        if item['question'].lower() == user_question:
            return item['answer']
    return "Sorry, I do not understand your question."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_question = request.json.get('question')
    answer = get_answer(user_question)
    return jsonify({'answer': answer})

if __name__ == '__main__':
    app.run(debug=True)
