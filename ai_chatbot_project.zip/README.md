# AI Chatbot for Customer Support

**Goal:** Demonstrate NLP and AI integration with a Flask web app.

## Contents
- `data/faq.json` — sample FAQ dataset
- `app.py` — Flask backend
- `frontend/index.html` — chat interface
- `requirements.txt` — Python dependencies
- `.gitignore`

## How to run
1. Create a Python virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run Flask app:
   ```bash
   python app.py
   ```
4. Open browser at `http://127.0.0.1:5000`

## Skills demonstrated
- Flask backend for AI application
- Frontend chat interface with HTML/CSS/JS
- Natural Language Processing (FAQ matching)
- Integration of AI with web technologies
