# Customer Review Sentiment Analysis — NLP Project

**Goal:** Classify customer reviews as positive or negative using NLP techniques.

## Contents
- `data/sample_reviews.csv` — synthetic sample dataset
- `notebooks/sentiment_analysis.ipynb` — notebook with preprocessing, training, evaluation, and visualization
- `images/sentiment_distribution.png` — sentiment distribution plot
- `models/` — optional folder to save trained model
- `requirements.txt` — dependencies
- `.gitignore`

## How to run
1. Create and activate a Python virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Jupyter and open the notebook:
   ```bash
   jupyter notebook notebooks/sentiment_analysis.ipynb
   ```

## Skills demonstrated
- Data preprocessing and text cleaning
- NLP feature extraction (Bag-of-Words)
- Machine learning classification (Logistic Regression)
- Model evaluation (accuracy, confusion matrix)
- Visualization of sentiment distribution
