# Youth Unemployment in South Africa — Data Analysis (Sample)

**Project:** Youth unemployment exploratory data analysis (sample data)

## Overview
This project demonstrates data cleaning, aggregation, and visualization techniques suitable for a junior data analyst or AI developer portfolio. It uses a synthetic but realistic sample dataset spanning 2015-2024 for multiple provinces, genders, and age groups.

## Files
- `data/youth_unemployment_sa.csv` — sample dataset
- `notebooks/analysis.ipynb` — Jupyter Notebook with analysis and plots
- `images/unemployment_trends.png` — generated visualization
- `requirements.txt` — required Python packages
- `.gitignore`

## How to run locally
1. Create a Python virtual environment and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate  # or venv\\Scripts\\activate on Windows
   ```
2. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Jupyter:
   ```bash
   jupyter notebook notebooks/analysis.ipynb
   ```

## Insights (sample)
- Sample data indicates a slight upward trend in youth unemployment (2015-2024).
- Higher unemployment is observed for ages 15-19 compared to 20-24 in the sample.
- Provinces such as Eastern Cape and KwaZulu-Natal show higher sample rates.

## Skills demonstrated
- Pandas data cleaning and aggregation
- Data visualization with Matplotlib / Seaborn
- Exploratory data analysis and insight generation

## Requirements
See `requirements.txt`
